Web je hostovaný také na githubu na adrese
https://vakkeh.github.io/staticka-stranka/